package com.company;

public class Main {

    public static void main(String[] args) {
	String name = "Вазген";
int age = 45;
int temp = 28;

        Boolean isSunny = true;
        if (age < 45) {
            System.out.println("Можно идти гулять");
        } if  (temp < -20, temp > 30 ) {
            System.out.println("Можно идти гулять");{
            }
        } if  (temp < 28) {
            System.out.println("Можно идти гулять");
    }
}
